export class StyleConstants {

  public backgroundColor?: string;
  public color?: string;
  public fontFamily?: string;
  public borderColor?: string;
  public transition?: string;

}