export interface LoaderState {
  show: boolean;
  refresh: boolean;
}