
export interface IForegroundNotification {
    showChat: boolean;
    showOrder: boolean;
}