import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-ordering',
  templateUrl: './group-ordering.component.html',
  styleUrls: ['./group-ordering.component.scss']
})
export class GroupOrderingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
